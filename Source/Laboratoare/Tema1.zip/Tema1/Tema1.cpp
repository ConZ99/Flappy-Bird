#include "Header.h"
#include <vector>
#include <iostream>
#include <Core/Engine.h>
#include "Transformari2D.h"
#include "Obiecte2D.h"
using namespace std;

Tema1::Tema1() {

}

Tema1::~Tema1() {

}

void Tema1::Init() {
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);
	//pana aici seteaza camera

	Mesh* obstacle = Obiecte2D::CreateSquare("obstacle", glm::vec3(0, 1, 0));
	AddMeshToList(obstacle);

	Mesh* body = Obiecte2D::CreateCircle("body", glm::vec3(0, 0.5, 0));
	AddMeshToList(body);

	Mesh* eye = Obiecte2D::CreateCircle("eye", glm::vec3(0, 0, 0));
	AddMeshToList(eye);

	Mesh* beak = Obiecte2D::CreateTriangle("beak", glm::vec3(1, 0, 0));
	AddMeshToList(beak);
	//Construiesc meshurile necesare

	float birdPos = 0.0f;
	float birdSpeed = 0.0f;
	float birdAcc = 0.0f;
	float gravity = 100.0f;
}


void Tema1::FrameStart() {
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glm::ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::Update(float deltaTimeSeconds) {

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transformari2D::Translate(275, 365) * Transformari2D::Scale(5, 5);
	RenderMesh2D(meshes["eye"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transformari2D::Translate(240, 360) * Transformari2D::Scale(25, 25);
	RenderMesh2D(meshes["body"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transformari2D::Translate(270, 360) * Transformari2D::Scale(20, 20);
	RenderMesh2D(meshes["body"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transformari2D::Translate(280, 360) * Transformari2D::Scale(30, 30);
	RenderMesh2D(meshes["beak"], shaders["VertexColor"], modelMatrix);

	

}

void Tema1::FrameEnd() {

}

void Tema1::OnInputUpdate(float deltaTime, int mods) {

}

void Tema1::OnKeyRelease(int key, int mods) {

}
void Tema1::OnKeyPress(int key, int mods) {
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) {
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) {
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) {
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) {
}

void Tema1::OnWindowResize(int width, int height) {
}